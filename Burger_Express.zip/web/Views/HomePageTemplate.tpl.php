<?php

/**
 * Šablona pro úvodní stránku
 */

?>

<div class="center-div">
    <p id="pHeading">Burger EXPRESS</p>
</div>